const UPDATE_DATA = [
  {
    imgSrc: "./images/arrow_circle_right.png",
    profileName: "ColumbiaAsia",
    message: "New Order",
    updatedTime: "2 Minutes Ago",
  },
  {
    imgSrc: "./images/arrow_circle_right.png",
    profileName: "DAS HealthCare",
    message: "NEW PRIORITY ORDER",
    updatedTime: "5 Minutes Ago",
  },
  {
    imgSrc: "./images/arrow_circle_right.png",
    profileName: "Manipal Hospital",
    message: "Received Order.",
    updatedTime: "6 Minutes Ago",
  },
];
